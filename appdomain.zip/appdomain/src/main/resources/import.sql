INSERT INTO project (id, pry_code, pry_name) VALUES (1, 'T1', 'prototipo');
INSERT INTO project (id, pry_code, pry_name) VALUES (2, 'T800', 'CSM-101');
INSERT INTO project (id, pry_code, pry_name) VALUES (3, 'T-801', 'CSM-101-E');