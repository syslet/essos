package com.cyberdyne.systems.appdomain.service;

public interface ProjectService {

}
