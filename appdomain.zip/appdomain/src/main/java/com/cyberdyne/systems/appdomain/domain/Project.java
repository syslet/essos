package com.cyberdyne.systems.appdomain.domain;

import jakarta.persistence.*;


@Entity
@Table(name = "project")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "pry_name")
    private String name;

    @Column(name = "pry_code")
    private String code;

}
