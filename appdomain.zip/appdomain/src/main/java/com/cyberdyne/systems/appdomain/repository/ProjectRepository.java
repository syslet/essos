package com.cyberdyne.systems.appdomain.repository;

import com.cyberdyne.systems.appdomain.domain.Project;
import org.springframework.data.repository.CrudRepository;

public interface ProjectRepository extends CrudRepository <Project, Long> {

}
