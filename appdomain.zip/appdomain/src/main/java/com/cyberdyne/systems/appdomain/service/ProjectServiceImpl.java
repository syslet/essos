package com.cyberdyne.systems.appdomain.service;

public class ProjectServiceImpl implements ProjectService {
}
